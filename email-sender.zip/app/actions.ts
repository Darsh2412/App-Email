"use server"

import nodemailer from "nodemailer"
import { writeFile } from "fs/promises"
import { join } from "path"
import { tmpdir } from "os"
import { v4 as uuidv4 } from "uuid"

export async function sendEmail(formData: FormData) {
  try {
    // Get credentials from form data or environment variables
    const gmailUser = (formData.get("gmailUser") as string) || process.env.GMAIL_USER
    const gmailAppPassword = (formData.get("gmailAppPassword") as string) || process.env.GMAIL_APP_PASSWORD

    // Validate credentials
    if (!gmailUser || !gmailAppPassword) {
      return {
        success: false,
        error: "Gmail credentials not provided. Please enter your Gmail address and App Password.",
      }
    }

    // Get form data
    const to = formData.get("to") as string
    const subject = formData.get("subject") as string
    const message = formData.get("message") as string
    const attachments = formData.getAll("attachments") as File[]

    // Validate inputs
    if (!to || !subject || !message) {
      return {
        success: false,
        error: "Missing required fields",
      }
    }

    // Process attachments
    const attachmentConfigs = await Promise.all(
      attachments.map(async (file) => {
        // Create a unique filename to avoid collisions
        const uniqueFilename = `${uuidv4()}-${file.name}`
        const tempFilePath = join(tmpdir(), uniqueFilename)

        // Convert File to Buffer and save to temp directory
        const buffer = Buffer.from(await file.arrayBuffer())
        await writeFile(tempFilePath, buffer)

        return {
          filename: file.name,
          path: tempFilePath,
          contentType: file.type,
        }
      }),
    )

    // Create transporter
    const transporter = nodemailer.createTransport({
      service: "gmail",
      auth: {
        user: gmailUser,
        pass: gmailAppPassword,
      },
    })

    // Send email
    await transporter.sendMail({
      from: gmailUser,
      to,
      subject,
      text: message,
      attachments: attachmentConfigs,
    })

    return { success: true }
  } catch (error) {
    console.error("Error sending email:", error)
    return {
      success: false,
      error: error instanceof Error ? error.message : "Unknown error occurred",
    }
  }
}

