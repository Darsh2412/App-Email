"use client"

import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { AlertCircle } from "lucide-react"

interface HelpModalProps {
  isOpen: boolean
  setIsOpen: (open: boolean) => void
}

export default function HelpModal({ isOpen, setIsOpen }: HelpModalProps) {
  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogContent className="max-w-3xl max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Gmail App Password Setup Guide</DialogTitle>
          <DialogDescription>Follow these steps to set up your Gmail App Password</DialogDescription>
        </DialogHeader>

        <Tabs defaultValue="overview">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="step-by-step">Step-by-Step</TabsTrigger>
            <TabsTrigger value="troubleshooting">Troubleshooting</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-4 mt-4">
            <Alert>
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>
                A Gmail App Password is a 16-character code that gives an app or device permission to access your Google
                Account. You'll need this to send emails through this application.
              </AlertDescription>
            </Alert>

            <div className="space-y-2">
              <h3 className="text-lg font-medium">Why do I need an App Password?</h3>
              <p className="text-sm text-muted-foreground">
                Google has increased security for Gmail accounts and no longer allows regular passwords for third-party
                apps. App passwords provide a secure way to grant access without compromising your main account
                password.
              </p>
            </div>

            <div className="space-y-2">
              <h3 className="text-lg font-medium">Prerequisites</h3>
              <ul className="list-disc list-inside text-sm text-muted-foreground space-y-1">
                <li>A Google/Gmail account</li>
                <li>2-Step Verification enabled on your account</li>
              </ul>
            </div>
          </TabsContent>

          <TabsContent value="step-by-step" className="space-y-4 mt-4">
            <div className="space-y-4">
              <div className="space-y-2">
                <h3 className="text-lg font-medium">Step 1: Enable 2-Step Verification</h3>
                <ol className="list-decimal list-inside space-y-1 text-sm text-muted-foreground">
                  <li>
                    Go to your Google Account at{" "}
                    <a
                      href="https://myaccount.google.com"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-primary underline"
                    >
                      myaccount.google.com
                    </a>
                  </li>
                  <li>Select "Security" from the navigation panel</li>
                  <li>Under "Signing in to Google," select "2-Step Verification"</li>
                  <li>Follow the steps to turn on 2-Step Verification</li>
                </ol>
              </div>

              <div className="space-y-2">
                <h3 className="text-lg font-medium">Step 2: Create an App Password</h3>
                <ol className="list-decimal list-inside space-y-1 text-sm text-muted-foreground">
                  <li>Go back to the "Security" section</li>
                  <li>Under "Signing in to Google," select "App passwords"</li>
                  <li>At the bottom, select "Select app" and choose "Mail"</li>
                  <li>Select "Other" from the device dropdown and enter "Email Sender App"</li>
                  <li>Click "Generate"</li>
                  <li>Google will display your 16-character app password</li>
                  <li>Copy this password (you won't be able to see it again)</li>
                </ol>
              </div>

              <div className="space-y-2">
                <h3 className="text-lg font-medium">Step 3: Use Your App Password</h3>
                <ol className="list-decimal list-inside space-y-1 text-sm text-muted-foreground">
                  <li>Return to the Email Sender App</li>
                  <li>Enter your Gmail address in the "Gmail Address" field</li>
                  <li>Enter the 16-character app password in the "App Password" field</li>
                  <li>The app password will be used only for this session and won't be stored permanently</li>
                </ol>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="troubleshooting" className="space-y-4 mt-4">
            <div className="space-y-4">
              <div className="space-y-2">
                <h3 className="text-lg font-medium">Common Issues</h3>

                <div className="space-y-1">
                  <h4 className="font-medium">App password not working</h4>
                  <p className="text-sm text-muted-foreground">
                    Make sure you've copied the entire 16-character password without spaces. If it still doesn't work,
                    try generating a new app password.
                  </p>
                </div>

                <div className="space-y-1">
                  <h4 className="font-medium">Can't find "App passwords" option</h4>
                  <p className="text-sm text-muted-foreground">
                    This option is only available if you have 2-Step Verification enabled. Make sure you've completed
                    Step 1 first.
                  </p>
                </div>

                <div className="space-y-1">
                  <h4 className="font-medium">Getting "Less secure app" warnings</h4>
                  <p className="text-sm text-muted-foreground">
                    This is expected. Using an app password bypasses this restriction.
                  </p>
                </div>
              </div>

              <div className="space-y-2">
                <h3 className="text-lg font-medium">Additional Resources</h3>
                <ul className="list-disc list-inside text-sm text-muted-foreground space-y-1">
                  <li>
                    <a
                      href="https://support.google.com/accounts/answer/185833"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-primary underline"
                    >
                      Google's Official App Passwords Guide
                    </a>
                  </li>
                  <li>
                    <a
                      href="https://support.google.com/mail/answer/7126229"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-primary underline"
                    >
                      Setting up Gmail with other email clients
                    </a>
                  </li>
                </ul>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  )
}

