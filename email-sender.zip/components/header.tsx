import { ThemeToggle } from "./theme-toggle"

export default function Header() {
  return (
    <header className="border-b">
      <div className="container mx-auto px-4 py-3 flex justify-between items-center">
        <div className="font-semibold text-lg">Email Sender</div>
        <ThemeToggle />
      </div>
    </header>
  )
}

