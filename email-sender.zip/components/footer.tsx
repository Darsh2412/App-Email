export default function Footer() {
  return (
    <footer className="py-4 border-t">
      <div className="container mx-auto px-4 text-center text-sm text-muted-foreground">
        &copy; Copyright 2025 B&R Industrial Automation
      </div>
    </footer>
  )
}

