"use client"

import type React from "react"

import { useState } from "react"
import { useForm } from "react-hook-form"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { AlertCircle, Loader2, X, Paperclip, ChevronDown, ChevronUp, HelpCircle } from "lucide-react"
import { sendEmail } from "@/app/actions"
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible"
import HelpModal from "./help-modal"

type FormData = {
  to: string
  subject: string
  message: string
  gmailUser: string
  gmailAppPassword: string
}

export default function EmailForm() {
  const [files, setFiles] = useState<File[]>([])
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [status, setStatus] = useState<{
    type: "success" | "error" | null
    message: string
  }>({ type: null, message: "" })
  const [isCredentialsOpen, setIsCredentialsOpen] = useState(false)
  const [isHelpOpen, setIsHelpOpen] = useState(false)

  const {
    register,
    handleSubmit,
    reset,
    formState: { errors },
  } = useForm<FormData>()

  const onSubmit = async (data: FormData) => {
    setIsSubmitting(true)
    setStatus({ type: null, message: "" })

    try {
      // Create FormData to send files
      const formData = new FormData()
      formData.append("to", data.to)
      formData.append("subject", data.subject)
      formData.append("message", data.message)
      formData.append("gmailUser", data.gmailUser)
      formData.append("gmailAppPassword", data.gmailAppPassword)

      // Append all files
      files.forEach((file) => {
        formData.append("attachments", file)
      })

      const result = await sendEmail(formData)

      if (result.success) {
        setStatus({
          type: "success",
          message: "Email sent successfully!",
        })
        reset()
        setFiles([])
      } else {
        setStatus({
          type: "error",
          message: result.error || "Failed to send email",
        })
      }
    } catch (error) {
      setStatus({
        type: "error",
        message: "An unexpected error occurred",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      const newFiles = Array.from(e.target.files)

      // Check file size (25MB limit per file)
      const invalidFiles = newFiles.filter((file) => file.size > 25 * 1024 * 1024)

      if (invalidFiles.length > 0) {
        setStatus({
          type: "error",
          message: "Some files exceed the 25MB limit per file",
        })
        return
      }

      setFiles((prev) => [...prev, ...newFiles])
    }
  }

  const removeFile = (index: number) => {
    setFiles(files.filter((_, i) => i !== index))
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <span>Compose Email</span>
          <Button variant="ghost" size="icon" onClick={() => setIsHelpOpen(true)} className="h-8 w-8">
            <HelpCircle className="h-5 w-5" />
            <span className="sr-only">Help</span>
          </Button>
        </CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
          <Collapsible open={isCredentialsOpen} onOpenChange={setIsCredentialsOpen} className="border rounded-md">
            <CollapsibleTrigger asChild>
              <Button variant="ghost" className="flex w-full justify-between p-4 rounded-md hover:bg-muted">
                <span className="font-medium">Sender Credentials</span>
                {isCredentialsOpen ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
              </Button>
            </CollapsibleTrigger>
            <CollapsibleContent className="p-4 pt-0 space-y-4 border-t">
              <div className="space-y-2">
                <Label htmlFor="gmailUser">Gmail Address</Label>
                <Input
                  id="gmailUser"
                  type="email"
                  placeholder="your.email@gmail.com"
                  {...register("gmailUser", { required: "Gmail address is required" })}
                />
                {errors.gmailUser && <p className="text-sm text-red-500">{errors.gmailUser.message}</p>}
              </div>

              <div className="space-y-2">
                <Label htmlFor="gmailAppPassword">App Password</Label>
                <Input
                  id="gmailAppPassword"
                  type="password"
                  placeholder="16-character app password"
                  {...register("gmailAppPassword", { required: "App password is required" })}
                />
                {errors.gmailAppPassword && <p className="text-sm text-red-500">{errors.gmailAppPassword.message}</p>}
                <p className="text-xs text-muted-foreground">
                  Don't know how to get an app password?{" "}
                  <Button variant="link" className="h-auto p-0 text-xs" onClick={() => setIsHelpOpen(true)}>
                    Click here for help
                  </Button>
                </p>
              </div>
            </CollapsibleContent>
          </Collapsible>

          <div className="space-y-2">
            <Label htmlFor="to">To</Label>
            <Input
              id="to"
              type="email"
              placeholder="recipient@example.com"
              {...register("to", { required: "Recipient email is required" })}
            />
            {errors.to && <p className="text-sm text-red-500">{errors.to.message}</p>}
          </div>

          <div className="space-y-2">
            <Label htmlFor="subject">Subject</Label>
            <Input
              id="subject"
              placeholder="Email subject"
              {...register("subject", { required: "Subject is required" })}
            />
            {errors.subject && <p className="text-sm text-red-500">{errors.subject.message}</p>}
          </div>

          <div className="space-y-2">
            <Label htmlFor="message">Message</Label>
            <Textarea
              id="message"
              placeholder="Your message"
              rows={6}
              {...register("message", { required: "Message is required" })}
            />
            {errors.message && <p className="text-sm text-red-500">{errors.message.message}</p>}
          </div>

          <div className="space-y-2">
            <Label htmlFor="attachments">Attachments</Label>
            <div className="flex items-center gap-2">
              <Button
                type="button"
                variant="outline"
                onClick={() => document.getElementById("file-upload")?.click()}
                className="flex items-center gap-2"
              >
                <Paperclip className="h-4 w-4" />
                Add Files
              </Button>
              <Input id="file-upload" type="file" multiple className="hidden" onChange={handleFileChange} />
              <p className="text-sm text-muted-foreground">Max 25MB per file</p>
            </div>

            {files.length > 0 && (
              <div className="mt-2 space-y-2">
                <p className="text-sm font-medium">Selected files:</p>
                <ul className="space-y-1">
                  {files.map((file, index) => (
                    <li key={index} className="flex items-center justify-between bg-muted p-2 rounded-md text-sm">
                      <div className="truncate max-w-[250px]">
                        {file.name} ({(file.size / (1024 * 1024)).toFixed(2)} MB)
                      </div>
                      <Button
                        type="button"
                        variant="ghost"
                        size="icon"
                        onClick={() => removeFile(index)}
                        className="h-6 w-6"
                      >
                        <X className="h-4 w-4" />
                      </Button>
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </div>

          {status.type && (
            <Alert variant={status.type === "error" ? "destructive" : "default"}>
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>{status.message}</AlertDescription>
            </Alert>
          )}

          <Button type="submit" disabled={isSubmitting} className="w-full">
            {isSubmitting ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Sending...
              </>
            ) : (
              "Send Email"
            )}
          </Button>
        </form>
      </CardContent>
      <HelpModal isOpen={isHelpOpen} setIsOpen={setIsHelpOpen} />
    </Card>
  )
}

