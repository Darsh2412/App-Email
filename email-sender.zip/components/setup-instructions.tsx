import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { AlertCircle } from "lucide-react"

export default function SetupInstructions() {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Gmail App Password Setup</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <Alert>
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>Important</AlertTitle>
          <AlertDescription>
            You need to set up a Gmail App Password to use this application. Regular passwords won't work due to
            Google's security policies.
          </AlertDescription>
        </Alert>

        <div className="space-y-4">
          <div>
            <h3 className="font-medium text-lg">Step 1: Enable 2-Step Verification</h3>
            <ol className="list-decimal list-inside space-y-1 mt-2 text-sm">
              <li>
                Go to your Google Account at{" "}
                <a
                  href="https://myaccount.google.com"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-primary underline"
                >
                  myaccount.google.com
                </a>
              </li>
              <li>Select "Security" from the navigation panel</li>
              <li>Under "Signing in to Google," select "2-Step Verification"</li>
              <li>Follow the steps to turn on 2-Step Verification</li>
            </ol>
          </div>

          <div>
            <h3 className="font-medium text-lg">Step 2: Create an App Password</h3>
            <ol className="list-decimal list-inside space-y-1 mt-2 text-sm">
              <li>Go back to the "Security" section</li>
              <li>Under "Signing in to Google," select "App passwords"</li>
              <li>At the bottom, select "Select app" and choose "Mail"</li>
              <li>Select "Other" from the device dropdown and enter "Email Sender App"</li>
              <li>Click "Generate"</li>
              <li>Google will display your 16-character app password</li>
              <li>Copy this password (you won't be able to see it again)</li>
            </ol>
          </div>

          <div>
            <h3 className="font-medium text-lg">Step 3: Configure Environment Variables</h3>
            <p className="text-sm mt-2">
              Create a <code>.env.local</code> file in your project root with the following variables:
            </p>
            <pre className="bg-muted p-2 rounded-md text-xs mt-2 overflow-x-auto">
              {`GMAIL_USER=your.email@gmail.com
GMAIL_APP_PASSWORD=your-16-character-app-password`}
            </pre>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

